package com.kpmg.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.rabbitmq.client.ConnectionFactory;

@Component
public class RabbitMQConfiguration
{

	public static final String topicExchangeName = "message_queue_exchange";

	public static final String queueName = "message_queue";

	@Bean
	Queue queue()
	{
		return new Queue(queueName, false);
	}

	@Bean
	TopicExchange exchange()
	{
		return new TopicExchange(topicExchangeName);
	}

	@Bean
	Binding binding(Queue queue, TopicExchange exchange)
	{
		return BindingBuilder.bind(queue).to(exchange).with("message_routing_key");
	}

	@Bean 
public CachingConnectionFactory rabbitConnectionFactory() throws Exception 
{
  ConnectionFactory factory = new ConnectionFactory(); 
  factory.setHost("b-f5801960-7b34-47d1-ba25-3ea82ddcd135.mq.us-east-1.amazonaws.com");
  factory.setUsername("root"); 
  factory.setPassword("Kolkata123456");
  factory.setPort(5671);
  factory.useSslProtocol(); 
  CachingConnectionFactory connectionFactory = new CachingConnectionFactory(factory); 
  return connectionFactory; 
}

}