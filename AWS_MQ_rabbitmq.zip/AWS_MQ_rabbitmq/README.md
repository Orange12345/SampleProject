# rabbitmq
Maven JAVA code to send and receive message in a RabbitMQ Queue

The class *ConnectionDetails* contains details of your RabbitMQ connection. We are using the default port 5671.
Replace the placeholders in *Send* and *Recv* class with your username, password and host name respectively.
